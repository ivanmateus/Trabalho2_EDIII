//Felipe Tiago de Carli - 10525686
//Gabriel de Andrade Dezan - 10525706
//Ivan Mateus de Lima Azevedo - 10525602

#ifndef ESCREVERNATELA_H_
#define ESCREVERNATELA_H_
#include <stdio.h>
#include <stdlib.h>

void binarioNaTela1(char *nomeArquivoBinario);
void trim(char *str);
void scan_quote_string(char *str);

#endif
